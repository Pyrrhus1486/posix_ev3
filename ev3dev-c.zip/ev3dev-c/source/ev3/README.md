## How to make and install the static library?

```
> cd source/ev3/
> make
> make install
```
